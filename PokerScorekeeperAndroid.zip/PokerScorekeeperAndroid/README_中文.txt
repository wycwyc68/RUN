扑克记分助手 Android 项目（第一版）

说明：这是 Android Studio 工程，不是已经编译好的 APK。
当前执行环境没有 Android SDK，无法在这里完成 APK 编译和签名。

如何生成 APK：
1. 在 Windows 电脑安装 Android Studio：https://developer.android.com/studio
2. 解压 PokerScorekeeperAndroid.zip。
3. Android Studio 选择 Open，打开解压后的 PokerScorekeeperAndroid 文件夹。
4. 等待 Gradle 同步完成；如提示安装 Android SDK 35，请按提示安装。
5. 菜单选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
6. 编译成功后点击右下角提示中的 locate，找到 app-debug.apk。
7. 将 app-debug.apk 传到 Android 手机，允许安装此来源的应用后安装。

本工程将现有网页放入 Android WebView，并启用 JavaScript 和本地存储。
玩家名称、局数和历史记录仍保存在本机；此版本尚未实现跨手机联网、房间邀请码和实时同步。

若要发布到 Google Play，需要另外生成签名版 AAB/APK，并完善隐私政策、应用图标及商店资料。
